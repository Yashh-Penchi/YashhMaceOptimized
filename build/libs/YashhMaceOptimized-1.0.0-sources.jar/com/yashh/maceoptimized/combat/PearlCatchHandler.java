package com.yashh.maceoptimized.combat;

import com.yashh.maceoptimized.config.ModConfig;
import com.yashh.maceoptimized.util.ChatUtils;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1802;
import net.minecraft.class_2868;

public class PearlCatchHandler {

    private static long lastPearlTime = 0;
    private static boolean swapped = false;
    private static boolean autoUsed = false;
    private static int autoUseTimer = -1; // counts down ticks before auto use

    public static void register() {

        // Detect pearl throw
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.field_9236 && player.method_5998(hand).method_31574(class_1802.field_8634)) {
                lastPearlTime = System.currentTimeMillis();
                swapped = false;
                autoUsed = false;
                autoUseTimer = -1;
            }
            return class_1269.field_5811;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!ModConfig.masterToggle) return;
            if (!ModConfig.pearlCatchEnabled) return;
            if (client.field_1724 == null) return;

            long timeSincePearl = System.currentTimeMillis() - lastPearlTime;
            if (timeSincePearl > 5000) return; // 5 sec window

            // Find wind charge slot
            int windSlot = -1;
            for (int i = 0; i < 9; i++) {
                if (client.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_49098)) {
                    windSlot = i;
                    break;
                }
            }
            if (windSlot == -1) return;

            // Step 1: Always swap to wind charge when looking up (both modes)
            if (!swapped && client.field_1724.method_36455() < -70) {
                if (client.field_1724.method_31548().method_67532() != windSlot) {
                    client.field_1724.method_31548().method_61496(windSlot);
                    if (client.method_1562() != null) {
                        client.method_1562().method_52787(
                                new class_2868(windSlot));
                    }
                    swapped = true;

                    // AUTO MODE: start countdown timer
                    if (ModConfig.autoPearlCatch) {
                        autoUseTimer = ModConfig.autoPearlCatchDelay;
                        ChatUtils.sendPearlCatch();
                    } else {
                        ChatUtils.sendPearlCatch();
                    }
                }
            }

            // Step 2: AUTO MODE only — countdown then auto use wind charge
            if (ModConfig.autoPearlCatch && swapped && !autoUsed) {
                if (autoUseTimer > 0) {
                    autoUseTimer--;
                } else if (autoUseTimer == 0) {
                    if (client.field_1761 != null
                            && client.field_1724.method_31548().method_67532() == windSlot) {
                        client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                        client.field_1724.method_6104(class_1268.field_5808);
                        autoUsed = true;
                        autoUseTimer = -1;
                        ChatUtils.sendPearlCatch();
                    }
                }
            }
        });
    }
}
