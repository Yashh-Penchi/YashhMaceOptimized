package com.yashh.maceoptimized.combat;

import com.yashh.maceoptimized.config.ModConfig;
import com.yashh.maceoptimized.util.ChatUtils;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_2868;
import net.minecraft.class_310;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class MaceSwapHandler {
    private static int revertTimer = -1;
    private static int originalSlot = -1;
    private static boolean isSwapping = false;

    public static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!ModConfig.masterToggle || !world.field_9236) return class_1269.field_5811;
            if (hand != class_1268.field_5808 || !(entity instanceof class_1309) || isSwapping) return class_1269.field_5811;

            class_1309 target = (class_1309) entity;

            boolean targetHasArmor = false;
            for (class_1304 slot : new class_1304[]{
                    class_1304.field_6169, class_1304.field_6174,
                    class_1304.field_6172, class_1304.field_6166}) {
                if (!target.method_6118(slot).method_7960()) {
                    targetHasArmor = true;
                    break;
                }
            }

            boolean isFalling = (player.field_6017 >= 1.5f && player.method_18798().field_1351 < 0);

            class_1799 held = player.method_6047();
            boolean holdingWeapon = held.method_7909() instanceof class_1743
                    || held.method_31574(class_1802.field_8091)
                    || held.method_31574(class_1802.field_8528)
                    || held.method_31574(class_1802.field_8371)
                    || held.method_31574(class_1802.field_8845)
                    || held.method_31574(class_1802.field_8802)
                    || held.method_31574(class_1802.field_22022);
            if (!holdingWeapon) return class_1269.field_5811;

            int foundSlot = -1;
            int fallbackSlot = -1;

            for (int i = 0; i < 9; i++) {
                class_1799 stack = player.method_31548().method_5438(i);
                if (!stack.method_31574(class_1802.field_49814)) continue;
                if (fallbackSlot < 0) fallbackSlot = i;
                if (isFalling && ModConfig.densityEnabled) {
                    if (getEnchantmentLevel(stack, "density") > 0) { foundSlot = i; break; }
                } else if (targetHasArmor && ModConfig.breachEnabled) {
                    if (getEnchantmentLevel(stack, "breach") > 0) { foundSlot = i; break; }
                }
            }

            int finalSlot = isFalling
                    ? (foundSlot != -1 ? foundSlot : fallbackSlot)
                    : foundSlot;

            if (finalSlot == -1 || player.method_31548().method_67532() == finalSlot) return class_1269.field_5811;

            originalSlot = player.method_31548().method_67532();
            isSwapping = true;
            player.method_31548().method_61496(finalSlot);
            if (class_310.method_1551().method_1562() != null) {
                class_310.method_1551().method_1562().method_52787(
                        new class_2868(finalSlot));
            }

            // Chat notification
            if (isFalling && foundSlot != -1) {
                ChatUtils.sendDensitySwap();
            } else if (isFalling) {
                ChatUtils.sendMaceSwap();
            } else if (targetHasArmor) {
                ChatUtils.sendBreachSwap();
            }

            revertTimer = ModConfig.revertDelayTicks + 1;
            return class_1269.field_5811;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null) return;
            if (revertTimer > 0) {
                revertTimer--;
            } else if (revertTimer == 0 && originalSlot != -1) {
                client.field_1724.method_31548().method_61496(originalSlot);
                if (client.method_1562() != null) {
                    client.method_1562().method_52787(new class_2868(originalSlot));
                }
                originalSlot = -1;
                revertTimer = -1;
                isSwapping = false;
            }
        });
    }

    private static int getEnchantmentLevel(class_1799 stack, String enchantName) {
        if (stack == null || stack.method_7960()) return 0;
        class_9304 enchants = stack.method_58694(class_9334.field_49633);
        if (enchants == null) return 0;
        for (class_6880<class_1887> entry : enchants.method_57534()) {
            if (entry.method_55840().toLowerCase().contains(enchantName.toLowerCase())) {
                return enchants.method_57536(entry);
            }
        }
        return 0;
    }
}
