package com.yashh.maceoptimized.util;

import net.minecraft.class_1657;
import net.minecraft.class_1802;

public class MaceUtils {
    public static int findMaceInHotbar(class_1657 player) {
        for (int i = 0; i < 9; i++) {
            if (player.method_31548().method_5438(i).method_31574(class_1802.field_49814)) {
                return i;
            }
        }
        return -1;
    }
}