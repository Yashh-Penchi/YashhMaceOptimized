package com.yashh.maceoptimized.util;

import net.minecraft.class_2561;
import net.minecraft.class_310;

public class ChatUtils {

    public static void sendActionBar(String message) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470(message), true);
        }
    }

    public static void sendChat(String message) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470(message), false);
        }
    }

    public static void sendDensitySwap() {
        sendChat("§6§l[§eYASHH MACE§6§l] §c§lDensity §7swap triggered! §i§7(§8Free Version§7)");
        sendChat(
                "§8 §7[§dPremium Version§7] §8§o\"Elytra Mace Assist, Wind Charge and Elytra Boost, Stun Slam Shield, Higher CPS MaceSpam for break Shield Durability, 360° anywhere PearlCatching, Resourcepack and Custom animations for Density and Breach with sound effects and much other...\"");
    }

    public static void sendBreachSwap() {
        sendChat("§6§l[§eYASHH MACE§6§l] §b§lBreach §7swap triggered! §i§7(§8Free Version§7)");
        sendChat("§7(§8upgrade to §dPremium §8for Elytra Mace Assist, 360° PearlCatch and more Advance feature§o!§r)");
    }

    public static void sendPearlCatch() {
        sendChat("§6§l[§eYASHH MACE§6§l] §t§lPearlCatch §7activated! §i§7(§8Free Version§7)");
        sendChat("§7(§8upgrade to §dPremium §8for Auto Elytra, 360° PearlCatch and more Advance feature§o!§r)");
    }

    public static void sendMaceSwap() {
        sendChat("§6§l[§eYASHH MACE§6§l] §q§lMace §7swap triggered! §i§7(§8Free Version§7)");
        sendChat("§7(§8upgrade to §dPremium §8for Elytra Mace Assist, 360° PearlCatch and more Advance feature§o!§r)");
    }

    // fallback generic
    public static void sendPrefixed(String message) {
        sendChat("§6§l[§eYASHH MACE§6§l] §r" + message);
    }
}
