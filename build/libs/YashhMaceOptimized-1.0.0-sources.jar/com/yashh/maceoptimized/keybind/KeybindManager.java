package com.yashh.maceoptimized.keybind;

import com.yashh.maceoptimized.config.ModConfig;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class KeybindManager {

    public static class_304 masterToggleKey;

    public static void register() {
        masterToggleKey = KeyBindingHelper.registerKeyBinding(
                new class_304(
                        "Toggle Yashh MaceOptimized",
                        class_3675.class_307.field_1668,
                        GLFW.GLFW_KEY_K,
                        "Yashh MaceOptimized"
                )
        );
    }

    public static void handleInputs() {
        while (masterToggleKey.method_1436()) {
            ModConfig.masterToggle = !ModConfig.masterToggle;
            class_2561 statusText = ModConfig.masterToggle
                    ? class_2561.method_43470("§6MaceOptimized §aEnable")
                    : class_2561.method_43470("§6MaceOptimized §cDisabled");
            if (class_310.method_1551().field_1724 != null) {
                class_310.method_1551().field_1724.method_7353(statusText, true);
            }
        }
    }
}
